Analyzing supermarket sales data
